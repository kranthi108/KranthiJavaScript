<?php

$db=mysqli_connect("athena.nitc.ac.in","b130417cs","b130417cs","db_b130417cs");
if($db==false){
	echo "ERROR:CANNOT CONNECT TO DATABASE";
	exit;
}
?>